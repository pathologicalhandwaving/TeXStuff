
# Vertex - A theme for LaTeX-Beamer

## Title page
![title page](./demo.png)

## Formulas and column breaks
![formula block](./demo-block.png)

