[![DOI](https://zenodo.org/badge/4357/famuvie/beamerthemesimple.svg)](https://zenodo.org/badge/latestdoi/4357/famuvie/beamerthemesimple)

# beamerthemesimple

A minimalist Beamer theme with a watermark in the background

Take a look at the self-explanatory `demo.pdf`

## Installation

- most simply, copy the file `beamerthemesimple.sty` in the same directory of your slides' source

- otherwise, avoid multiple copies by installing the file in your personal `texmf` tree
