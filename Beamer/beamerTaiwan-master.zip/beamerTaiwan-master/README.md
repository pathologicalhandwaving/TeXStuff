# beamerTaiwan

beamerTaiwan is a simple Beamer theme based on the beautiful green color of Taiwan. It uses tricks borrowed from various standard beamer themes along with a carefully-tuned green color with shade as the background. It has been used by two popular machine learning MOOCs [Machine Learning Foundations and Machine Learning Techniques](http://www.csie.ntu.edu.tw/~htlin/mooc/). See [sample PDF](sample/sample.pdf) for what the theme looks like! Feedbacks and Pull Requests are welcomed.


