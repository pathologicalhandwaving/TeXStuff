# Beamer Theme Naked

A minimalistic latex-beamer theme for presenting naked.
http://presentationzen.blogs.com/presentationzen/2005/10/make_your_next_.html

## Demo

Just execute `make` and see the resulting example.pdf file.
Also try the `\usecolortheme{dark}` option, for white-on-black slides.

## Feedback

Patches and suggestions are welcome. Send them to
Andreas Zwinkau <beza1e1@web.de>

